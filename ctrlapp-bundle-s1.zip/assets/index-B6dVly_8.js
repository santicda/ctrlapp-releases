const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-CUHqYixL.js","./index-fhbrUpaT.js","./index-Cv_bRRr0.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-fhbrUpaT.js";const _=e("Browser",{web:()=>o(()=>import("./web-CUHqYixL.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
