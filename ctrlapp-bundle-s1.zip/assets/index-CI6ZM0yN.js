const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-gMDzxzkK.js","./index-DkccB6gU.js","./index-Cv_bRRr0.css"])))=>i.map(i=>d[i]);
import{r as e,_ as o}from"./index-DkccB6gU.js";const _=e("Browser",{web:()=>o(()=>import("./web-gMDzxzkK.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(r=>new r.BrowserWeb)});export{_ as Browser};
